import React from 'react';
import './Header.css'; // Import the CSS file for styling
import logo from './assets/Logo.png';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <img src={logo} alt="Company Logo" />
        <span>Intranet</span>
      </div>
      {/* <nav className="nav">
        <a href="/" className="nav-link">Home</a>
        <div className="dropdown">
          <button className="dropbtn">Company</button>
          <div className="dropdown-content">
            <a href="/about">About Us</a>
            <a href="/team">Our Team</a>
            <a href="/careers">Careers</a>
          </div>
        </div>
        <a href="/platform" className="nav-link">Platform</a>
        <a href="/document" className="nav-link">Document</a>
      </nav> */}
    </header>
  );
};

export default Header;
