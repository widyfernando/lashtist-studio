import React from 'react';
import './Newsletter.css';
import information from './assets/Information.png';

const Newsletter = () => {
  return (
    <div className="newsletter-container">
      <div className="main-article">
        <h2>Family Gathering Ada Lagi!</h2>
        <p>A.O.L.I.E. Five basic values that form our foundation in Dynamic, smooth and tough to face changes and competition to achieve growth</p>
        <p><strong>8 Februari 2024 - HCM Department</strong></p>
        <img src={information} alt="Team collaboration" className="main-image" />
      </div>
      <div className="side-announcements">
        <div className="announcement">
          <h3>Karyawan Baru Bulan Februari 2024!</h3>
          <p>Kenalan sama keluarga baru Cakaya Jakarta Group 2024. <a href="#">Read more ...</a></p>
          <p><strong>7 Februari 2024 | HCM Department</strong></p>
        </div>
        <div className="announcement">
          <h3>Bonus Cair Bulan Mei!</h3>
          <p>Kabarin semua keluarga baru Cakaya Jakarta Group 2024. <a href="#">Read more ...</a></p>
          <p><strong>7 Februari 2024 | HCM Department</strong></p>
        </div>
        <div className="announcement">
          <h3>Inilah Pemenang Kaizen Award 2024!</h3>
          <p>Kenalan sama keluarga baru Cakaya Jakarta Group 2024. <a href="#">Read more ...</a></p>
          <p><strong>7 Februari 2024 | HCM Department</strong></p>
        </div>
        <div className="announcement">
          <h3>Penetapan Jadwal Libur Lebaran 2024!</h3>
          <p>Kabarin semua keluarga baru Cakaya Jakarta Group 2024. <a href="#">Read more ...</a></p>
          <p><strong>5 Februari 2024 | HCM Department</strong></p>
        </div>
      </div>
    </div>
  );
};

export default Newsletter;
