// src/IntranetDashboard.js

import React from 'react';
import './IntranetDashboard.css'; // Create a CSS file for styles

const IntranetDashboard = () => {
  return (
    <div className="dashboard">
      <div className="header">
        <div className="logo-title">
          <div className="logo">
            <span role="img" aria-label="logo">📌</span>
          </div>
          <div className="title">
            <h1>CJ Intranet</h1>
          </div>
        </div>
        <p className="description">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
      </div>

      <div className="content">
        <div className="section">
          <h2>Website</h2>
          <ul>
            <li>Cahaya Jakarta Group</li>
            <li>Cahaya Jakarta Printing</li>
            <li>Cahaya Jakarta Packaging</li>
            <li>Theia</li>
            <li>KitaLabel</li>
          </ul>
        </div>
        <div className="section">
          <h2>Document</h2>
          <ul>
            <li>Human Resource</li>
            <li>General Affair</li>
            <li>QMS</li>
          </ul>
        </div>
        <div className="section">
          <h2>Platform</h2>
          <ul>
            <li>CMIS</li>
            <li>IT Ticket</li>
            <li>Quality Patrol</li>
            <li>Human Resource</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default IntranetDashboard;
