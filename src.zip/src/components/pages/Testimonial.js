import React from "react";

const testimonials = [
  { name: "Siti A.", text: "Hasil Sulam Alisnya luar biasa! Rapi dan natural." },
  { name: "Rina L.", text: "Nail Art cantik dan tahan lama, suka banget!" },
  { name: "Maya W.", text: "Eyelash Extension membuat mataku lebih hidup!" },
];

const Testimonial = () => {
  return (
    <div className="testimonial-list">
      {testimonials.map((t,i)=>(
        <div key={i} className="testimonial-card">
          <p>"{t.text}"</p>
          <h4>- {t.name}</h4>
        </div>
      ))}
    </div>
  );
};

export default Testimonial;
