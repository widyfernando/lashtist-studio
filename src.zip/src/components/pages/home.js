// src/components/pages/Home.js
import React, { useState, useEffect } from "react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import "./Home.css";
import AOS from "aos";
import "aos/dist/aos.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faHandSparkles, faMagic, faPalette } from "@fortawesome/free-solid-svg-icons";

import Countdown from "./Countdown";
import Testimonial from "./Testimonial";
import Gallery from "./Gallery";
import Frequence from "./frequence";

// Hero & Type Images (dummy)
import img1 from "../assets/1.jpg";
import img2 from "../assets/slide/slide-2.jpg";
import img3 from "../assets/slide/slide-3.jpg";
import imgClassic from "../assets/1.jpg";
import imgVolume from "../assets/1.jpg";
import imgMega from "../assets/1.jpg";
import imgHybrid from "../assets/1.jpg";
import imgRussian from "../assets/1.jpg";
import imgFrench from "../assets/1.jpg";
import imgGlitter from "../assets/1.jpg";
import imgMatte from "../assets/1.jpg";
import img3D from "../assets/1.jpg";
import imgGel from "../assets/1.jpg";
import imgBasic from "../assets/1.jpg";
import imgAdvanced from "../assets/1.jpg";
import imgKeratin from "../assets/1.jpg";
import imgSulamNatural from "../assets/1.jpg";
import imgSulamTebal from "../assets/1.jpg";
import imgSulamBibir from "../assets/1.jpg";
import imgSulamBold from "../assets/1.jpg";

// ====== Modal Component ======
function BookingModal({ isOpen, onClose, serviceName, typeName }) {
    const [name, setName] = useState("");
    const [datetime, setDatetime] = useState(null);

    const handleBooking = () => {
        if (!name || !datetime) {
            alert("Tolong isi nama dan pilih tanggal & jam booking!");
            return;
        }

        const message = `
Nama: ${name}
Treatment: ${serviceName} - ${typeName}
Hari, tanggal, jam: ${datetime.toLocaleString()}

Untuk keep slot wajib DP sebesar 50rb ya dear
BCA an Lin Karlina
3432122392

Note:
‼️ Reschedule/cancel dadakan hari H saat jam nya tiba = DP HANGUS
‼️ Reschedule lebih dari 2x = DP HANGUS
‼️ Selama tidak ada DP yg masuk, kami anggap tidak ada booking
‼️ Jika terlambat bersedia ganti jadwal
‼️ Sudah DP dianggap setuju dgn peraturan diatas
    `;
        window.open(`https://wa.me/6281295354464?text=${encodeURIComponent(message)}`, "_blank");
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="modal-backdrop">
            <div className="modal-content">
                <h3>Booking {serviceName} - {typeName}</h3>

                {/* Input Nama dan Date Picker sejajar */}
                <div className="modal-row">
                    <input
                        type="text"
                        placeholder="Nama"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="modal-input"
                    />
                    <DatePicker
                        selected={datetime}
                        onChange={(date) => setDatetime(date)}
                        showTimeSelect
                        dateFormat="dd/MM/yyyy HH:mm"
                        placeholderText="Pilih tanggal & jam"
                        className="datepicker-input"
                    />
                </div>

                {/* Tombol Aksi */}
                <div className="modal-actions">
                    <button onClick={handleBooking} className="btn-booking">Kirim WA</button>
                    <button onClick={onClose} className="btn-cancel">Batal</button>
                </div>
            </div>
        </div>

    );
}

// ====== Main Home Component ======
function Home() {
    // ====== Data Layanan ======
    const services = [
        {
            id: 1,
            name: "Eyelash Extension",
            icon: faEye,
            types: [
                { id: 1, name: "Classic Lash", desc: "Bulu mata natural", price: "Rp150.000", img: imgClassic },
                { id: 2, name: "Volume Lash", desc: "Bulu mata lebih tebal", price: "Rp250.000", img: imgVolume },
                { id: 3, name: "Mega Volume", desc: "Tampilan dramatis maksimal", price: "Rp350.000", img: imgMega },
                { id: 4, name: "Hybrid Lash", desc: "Campuran classic & volume", price: "Rp280.000", img: imgHybrid },
                { id: 5, name: "Russian Volume", desc: "Bulu mata super tebal", price: "Rp400.000", img: imgRussian },
            ],
        },
        {
            id: 2,
            name: "Nail Art",
            icon: faPalette,
            types: [
                { id: 1, name: "French Tips", desc: "Kuku cantik & elegan", price: "Rp100.000", img: imgFrench },
                { id: 2, name: "Glitter Design", desc: "Kuku stylish & berkilau", price: "Rp120.000", img: imgGlitter },
                { id: 3, name: "Matte Design", desc: "Kuku modern & elegan", price: "Rp110.000", img: imgMatte },
                { id: 4, name: "3D Nail Art", desc: "Desain 3D unik", price: "Rp150.000", img: img3D },
                { id: 5, name: "Gel Polish", desc: "Tahan lama & glossy", price: "Rp130.000", img: imgGel },
            ],
        },
        {
            id: 3,
            name: "Lash Lift",
            icon: faMagic,
            types: [
                { id: 1, name: "Basic Lift", desc: "Bulu mata lentik alami", price: "Rp180.000", img: imgBasic },
                { id: 2, name: "Advanced Lift", desc: "Lentik & tebal", price: "Rp220.000", img: imgAdvanced },
                { id: 3, name: "Keratin Lash Lift", desc: "Lentik + nutrisi keratin", price: "Rp250.000", img: imgKeratin },
            ],
        },
        {
            id: 4,
            name: "Sulam Alis / Bibir",
            icon: faHandSparkles,
            types: [
                { id: 1, name: "Sulam Alis Natural", desc: "Alis rapi & natural", price: "Rp200.000", img: imgSulamNatural },
                { id: 2, name: "Sulam Alis Tebal", desc: "Alis lebih tegas & penuh", price: "Rp220.000", img: imgSulamTebal },
                { id: 3, name: "Sulam Bibir Natural", desc: "Bibir merona alami", price: "Rp250.000", img: imgSulamBibir },
                { id: 4, name: "Sulam Bibir Bold", desc: "Bibir tegas & penuh warna", price: "Rp280.000", img: imgSulamBold },
            ],
        },
    ];

    // ====== State ======
    const [activeService, setActiveService] = useState(services[0].id);
    const [search, setSearch] = useState("");
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedType, setSelectedType] = useState(null);

    const currentService = services.find((s) => s.id === activeService);
    const activeServiceName = currentService?.name || "";
    const filteredTypes = currentService.types.filter((type) =>
        type.name.toLowerCase().includes(search.toLowerCase())
    );

    useEffect(() => {
        AOS.init({ duration: 1000, once: true });
    }, []);

    // ====== Slides Hero ======
    const slides = [
        { img: img1, alt: "Sulam Alis", title: "✨ Sulam Alis Natural ✨", desc: "Tampil percaya diri dengan alis rapi & indah setiap hari" },
        { img: img2, alt: "Eyelash Lashlift", title: "🌸 Eyelash Lashlift 🌸", desc: "Bulu mata lentik alami tanpa extension" },
        { img: img3, alt: "Nail Art", title: "💅 Nail Art Cantik 💅", desc: "Kuku indah & stylish dengan desain terbaru" },
        { img: img1, alt: "Eyelash Extension", title: "💖 Eyelash Extension 💖", desc: "Tampil glamor dengan bulu mata tebal & tahan lama" },
    ];

    return (
        <div className="home">
            {/* Hero Carousel */}
            <Carousel autoPlay infiniteLoop showThumbs={false} showStatus={false} interval={3500} transitionTime={800} swipeable emulateTouch>
                {slides.map((s, i) => (
                    <div key={i}>
                        <img src={s.img} alt={s.alt} />
                        <div className="caption">
                            <h2>{s.title}</h2>
                            <p>{s.desc}</p>
                            <button className="cta-btn" onClick={() => { setSelectedType({ name: "" }); setModalOpen(true); }}>Booking Sekarang</button>
                        </div>
                    </div>
                ))}
            </Carousel>

            {/* Services Section */}
            <section className="services-highlight">
                <h2 data-aos="fade-up">Layanan Utama</h2>

                {/* Service Tabs */}
                <div className="service-tabs">
                    {services.map((s) => (
                        <button
                            key={s.id}
                            className={`tab-btn ${activeService === s.id ? "active" : ""}`}
                            onClick={() => setActiveService(s.id)}
                        >
                            <FontAwesomeIcon icon={s.icon} /> {s.name}
                        </button>
                    ))}
                </div>

                {/* Search input */}
                <input
                    type="text"
                    placeholder="Cari tipe layanan..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="search-input"
                />

                {/* Tampilkan tipe-tipe layanan */}
                {/* Tampilkan tipe-tipe layanan sebagai slider */}
                <div className="types-slider">
                    {filteredTypes.map((type) => (
                        <div key={type.id} className="type-card">
                            <img
                                src={type.img}
                                alt={type.name}
                                style={{
                                    width: "100%",
                                    height: "150px",
                                    objectFit: "cover",
                                    borderRadius: "15px"
                                }}
                            />
                            <h3>{type.name}</h3>
                            <p>{type.desc}</p>
                            <p><strong>{type.price}</strong></p>
                            <button
                                className="btn-booking"
                                onClick={() => {
                                    setSelectedType(type);
                                    setModalOpen(true);
                                }}
                            >
                                Booking Sekarang
                            </button>
                        </div>
                    ))}
                </div>

            </section>


            {/* Booking Modal */}
            <BookingModal
                isOpen={modalOpen}
                onClose={() => setModalOpen(false)}
                serviceName={activeServiceName}
                typeName={selectedType?.name}
            />

            {/* Promo, Testimonial, Gallery, Team, FAQ, Footer */}
            <section className="promo" data-aos="fade-up">
                <h2>Promo Terbaru 🎉</h2>
                <Countdown />
                <p>Diskon <strong>20%</strong> untuk semua treatment di bulan ini!</p>
            </section>

            <section className="testimonials" data-aos="fade-up">
                <h2>Testimoni Pelanggan</h2>
                <Testimonial />
            </section>

            <section className="gallery" data-aos="fade-up">
                <h2>Galeri Before-After</h2>
                <Gallery />
            </section>

            <section className="team" data-aos="fade-up">
                <h2>Tim Profesional Kami</h2>
                <div className="team-list">
                    <div className="team-card">Jane Doe<br />Eyelash Specialist</div>
                    <div className="team-card">Anna Smith<br />Nail Art Expert</div>
                    <div className="team-card">Lina Rose<br />Sulam Alis Artist</div>
                </div>
            </section>

            <section className="faq" data-aos="fade-up">
                <h2>Tips & FAQ</h2>
                <Frequence />
            </section>

            <footer className="footer" data-aos="fade-up">
                <p>📍 Jl. Cantik No.1, Jakarta | 📞 WA: 0812-9535-4464 | ✉️ info@beauty.com</p>
                <p>Instagram | TikTok | Facebook</p>
                <p>© 2025 Beauty Service</p>
            </footer>
        </div>
    );
}

export default Home;
