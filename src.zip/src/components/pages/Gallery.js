import React, { useState } from "react";

const images = [
  { src: "/assets/1.jpg", alt:"Before-After 1" },
  { src: "/assets/2.jpg", alt:"Before-After 2" },
  { src: "/assets/2.jpg", alt:"Before-After 3" },
  { src: "/assets/3.jpg", alt:"Before-After 4" },
];

const Gallery = () => {
  const [lightbox, setLightbox] = useState(null);

  return (
    <div>
      <div className="gallery-grid">
        {images.map((img,i)=>(
          <div key={i} className="gallery-item" onClick={()=>setLightbox(i)}>
            <img src={img.src} alt={img.alt} />
            <div className="overlay">{img.alt}</div>
          </div>
        ))}
      </div>

      {lightbox !== null && (
        <div className="lightbox" onClick={()=>setLightbox(null)}>
          <img src={images[lightbox].src} alt={images[lightbox].alt} />
        </div>
      )}
    </div>
  );
};

export default Gallery;
