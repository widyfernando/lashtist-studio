// src/components/pages/services/EyelashExtension.js
import React, { useState } from "react";
import "./EyelashExtension.css"; // CSS khusus halaman eyelash

const eyelashTypes = [
  { id: 1, name: "Classic Lash", desc: "Bulu mata natural, tipis, dan elegan.", price: "Rp150.000" },
  { id: 2, name: "Volume Lash", desc: "Bulu mata lebih tebal & bervolume.", price: "Rp250.000" },
  { id: 3, name: "Hybrid Lash", desc: "Perpaduan classic & volume.", price: "Rp200.000" },
  { id: 4, name: "Mega Volume", desc: "Bulu mata super tebal dan dramatis.", price: "Rp350.000" },
];

const EyelashExtension = () => {
  const [search, setSearch] = useState("");

  const filteredLashes = eyelashTypes.filter(type =>
    type.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="eyelash-page">
      <h1>Eyelash Extension</h1>
      <p>Selamat datang di layanan Eyelash Extension kami! Pilih tipe sesuai gaya yang Anda inginkan:</p>

      <input
        type="text"
        placeholder="Cari tipe eyelash..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="search-input"
      />

      <div className="eyelash-grid">
        {filteredLashes.map(lash => (
          <div key={lash.id} className="eyelash-card">
            <h3>{lash.name}</h3>
            <p>{lash.desc}</p>
            <p><strong>{lash.price}</strong></p>
            <button
              className="btn-booking"
              onClick={() => window.open("https://wa.me/6281295354464", "_blank")}
            >
              Booking Sekarang
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EyelashExtension;
