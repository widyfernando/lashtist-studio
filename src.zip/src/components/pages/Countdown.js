import React, { useEffect, useState } from "react";

const Countdown = ({ targetDate = "2025-12-31T23:59:59" }) => {
  const [timeLeft, setTimeLeft] = useState({ days:0,hours:0,minutes:0,seconds:0 });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const target = new Date(targetDate);
      const diff = target - now;

      if (diff <= 0) {
        clearInterval(interval);
        setTimeLeft({ days:0,hours:0,minutes:0,seconds:0 });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTimeLeft({ days,hours,minutes,seconds });
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate]);

  return (
    <div className="countdown">
      <span className="countdown-item">{timeLeft.days}d</span> :
      <span className="countdown-item">{timeLeft.hours}h</span> :
      <span className="countdown-item">{timeLeft.minutes}m</span> :
      <span className="countdown-item">{timeLeft.seconds}s</span>
    </div>
  );
};

export default Countdown;
