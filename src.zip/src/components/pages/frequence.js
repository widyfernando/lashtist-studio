import React, { useState } from "react";

const faqs = [
  {
    question: "Berapa lama Sulam Alis bertahan?",
    answer: "Sekitar 1-3 tahun tergantung perawatan."
  },
  {
    question: "Apakah Nail Art merusak kuku?",
    answer: "Tidak, kami menggunakan cat berkualitas & aman."
  },
  {
    question: "Apakah Lash Lift aman untuk mata?",
    answer: "Ya, menggunakan bahan yang aman untuk bulu mata alami."
  },
];

const Frequence = () => {
  const [active, setActive] = useState(null);

  const toggle = index => setActive(active === index ? null : index);

  return (
    <div className="faq-list">
      {faqs.map((f,i)=>(
        <div key={i} className={`faq-item ${active===i ? "active":""}`}>
          <div className="faq-question" onClick={()=>toggle(i)}>
            {f.question} <span>{active===i ? "-" : "+"}</span>
          </div>
          <div className="faq-answer">{f.answer}</div>
        </div>
      ))}
    </div>
  );
};

export default Frequence;
