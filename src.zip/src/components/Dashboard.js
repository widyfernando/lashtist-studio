// src/Dashboard.js
import React from 'react';
import './Dashboard.css'; // Import the CSS file for styling

const Dashboard = () => {
  const services = [
    { name: 'Eyelash Extension', icon: '👁️', desc: 'Bulu mata lentik dan tahan lama dengan berbagai gaya sesuai keinginan.' },
    { name: 'Nail Art', icon: '💅', desc: 'Kuku cantik dengan desain unik, warna menarik, dan sentuhan artistik.' },
    { name: 'Lash Lift', icon: '✨', desc: 'Alternatif alami tanpa extension untuk membuat bulu mata lebih lentik dan indah.' },
    { name: 'Sulam Alis', icon: '🎯', desc: 'Membentuk alis yang natural dan rapi sesuai bentuk wajah.' },
  ];

  return (
    <div className="dashboard">
      <h2>Our Beauty Services</h2>
      <p>Kami menghadirkan perawatan terbaik untuk menunjang penampilanmu.</p>
      <div className="grid-container">
        {services.map((service) => (
          <div className="grid-item" key={service.name}>
            <div className="icon">{service.icon}</div>
            <div className="name">{service.name}</div>
            <p className="desc">{service.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
