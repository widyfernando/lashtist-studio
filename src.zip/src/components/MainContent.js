import React from 'react';
// import ImageSlider from './Imageslider';
import ImageSlider from './Imageslider';

function MainContent() {
  return (
    <main>
      <h2>Main Content</h2>
      <ImageSlider/>
      <p>This is where your main content will go.</p>
    </main>
  );
}

export default MainContent;
