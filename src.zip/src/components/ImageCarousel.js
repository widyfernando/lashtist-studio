import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import './ImageCarousel.css';
import slide1 from './assets/1.jpg';
import slide2 from './assets/slide/slide-2.jpg';
import slide3 from './assets/slide/slide-3.jpg';
import slide4 from './assets/1.jpg'; // Tambahan gambar

const ImageCarousel = () => {
  return (
    <Carousel 
      autoPlay 
      infiniteLoop 
      showThumbs={false} 
      showStatus={false}
      interval={3500}
      transitionTime={800}
    >
      {/* Sulam Alis */}
      <div>
        <img src={slide1} alt="Sulam Alis" />
        <div className="caption">
          <h2>✨ Sulam Alis Natural ✨</h2>
          <p>Tampil percaya diri dengan alis rapi & indah setiap hari</p>
          <button 
            className="cta-btn" 
            onClick={() => window.open("https://wa.me/6281234567890", "_blank")}
          >
            Booking Sekarang
          </button>
        </div>
      </div>

      {/* Eyelash Lashlift */}
      <div>
        <img src={slide2} alt="Eyelash Lashlift" />
        <div className="caption">
          <h2>🌸 Eyelash Lashlift 🌸</h2>
          <p>Bulu mata lentik alami tanpa extension</p>
          <button 
            className="cta-btn" 
            onClick={() => window.open("https://wa.me/6281234567890", "_blank")}
          >
            Booking Sekarang
          </button>
        </div>
      </div>

      {/* Nail Art */}
      <div>
        <img src={slide3} alt="Nail Art" />
        <div className="caption">
          <h2>💅 Nail Art Cantik 💅</h2>
          <p>Kuku indah & stylish dengan desain terbaru</p>
          <button 
            className="cta-btn" 
            onClick={() => window.open("https://wa.me/6281234567890", "_blank")}
          >
            Booking Sekarang
          </button>
        </div>
      </div>

      {/* Eyelash Extension */}
      <div>
        <img src={slide4} alt="Eyelash Extension" />
        <div className="caption">
          <h2>💖 Eyelash Extension 💖</h2>
          <p>Tampil glamor dengan bulu mata tebal & tahan lama</p>
          <button 
            className="cta-btn" 
            onClick={() => window.open("https://wa.me/6281234567890", "_blank")}
          >
            Booking Sekarang
          </button>
        </div>
      </div>
    </Carousel>
  );
};

export default ImageCarousel;
