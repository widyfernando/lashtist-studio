import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <div className="footer">
      <div className="footer-content">
        <p>&copy; 2023 Intranet, Inc.</p>
        <ul className="footer-links">
          <li>Privacy Policy</li>
          <li>Terms of Service</li>
          <li>Cookie Settings</li>
        </ul>
        <div className="language-selector">
          <span>English (US)</span>
          <img src="path/to/flag.png" alt="US Flag" />
        </div>
      </div>
    </div>
  );
};

export default Footer;
