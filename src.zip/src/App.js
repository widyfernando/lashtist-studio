// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";

// Components
import Header from "./components/Header";
import Footer from "./components/Footer";
import EyelashExtension from "./components/pages/services/EyelashExtension";
// Pages
import Home from "./components/pages/home";
// import Services from "./pages/Services";
// import Gallery from "./pages/Gallery";
// import Booking from "./pages/Booking";
// import About from "./pages/About";
// import Testimonials from "./pages/Testimonials";
// import Contact from "./pages/Contact";

function App() {
  return (
    <Router>
      <div className="App">
        <Header />

        <main>
          <Routes>
            <Route path="/" element={<Home />} />
           <Route path="/services/eyelash-extension" element={<EyelashExtension />} />
            {/* <Route path="/services" element={<Services />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/booking" element={<Booking />} />
            <Route path="/about" element={<About />} />
            <Route path="/testimonials" element={<Testimonials />} />
            <Route path="/contact" element={<Contact />} /> */}
          </Routes>
        </main>

        {/* <Footer /> */}
      </div>
    </Router>
  );
}

export default App;
